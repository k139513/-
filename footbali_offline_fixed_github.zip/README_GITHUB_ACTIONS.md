# ساخت خودکار APK فوتبالی

این نسخه برای حالت آزمایشی آفلاین تنظیم شده است و در شروع برنامه نیازی به Supabase، ایمیل، رمز عبور یا اینترنت ندارد.

## ساخت APK
1. محتویات پروژه را در یک GitHub repository قرار دهید.
2. به Actions بروید.
3. Workflow با نام **Build Footbali APK** را اجرا کنید.
4. از Artifacts فایل `footbali-apk` را دانلود کنید.
5. داخل آن `app-release.apk` را روی گوشی نصب کنید.

Workflow هنگام build فایل‌های Android را با `flutter create` ایجاد می‌کند.
