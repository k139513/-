import 'dart:convert';
import 'package:http/http.dart' as http;
import 'config.dart';
import 'models.dart';

class FootballApi {
  Future<List<MatchModel>> todayMatches() async {
    if (!AppConfig.hasFootballApi) return _demo();

    final uri = Uri.parse('${AppConfig.footballApiBaseUrl}/fixtures');
    final response = await http.get(uri, headers: {
      'x-apisports-key': AppConfig.footballApiKey,
      'Authorization': 'Bearer ${AppConfig.footballApiKey}',
    });

    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw Exception('Football API error: ${response.statusCode}');
    }

    final data = jsonDecode(response.body);
    final rows = (data['response'] as List?) ?? const [];
    return rows.map((x) {
      final f = x['fixture'] ?? {};
      final teams = x['teams'] ?? {};
      final goals = x['goals'] ?? {};
      return MatchModel(
        id: '${f['id']}',
        league: '${x['league']?['name'] ?? ''}',
        home: '${teams['home']?['name'] ?? ''}',
        away: '${teams['away']?['name'] ?? ''}',
        time: '${f['date'] ?? ''}',
        status: '${f['status']?['short'] ?? 'NS'}',
        homeScore: goals['home'],
        awayScore: goals['away'],
      );
    }).toList();
  }

  List<MatchModel> _demo() => const [
    MatchModel(id: '1', league: 'لیگ قهرمانان اروپا', home: 'رئال مادرید', away: 'منچسترسیتی', time: '22:30', status: 'NS'),
    MatchModel(id: '2', league: 'لالیگا', home: 'بارسلونا', away: 'اتلتیکومادرید', time: '20:00', status: 'NS'),
    MatchModel(id: '3', league: 'لیگ برتر انگلیس', home: 'آرسنال', away: 'لیورپول', time: '18:30', status: 'NS'),
  ];
}
