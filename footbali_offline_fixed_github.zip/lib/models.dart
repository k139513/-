class MatchModel {
  final String id;
  final String league;
  final String home;
  final String away;
  final String time;
  final int? homeScore;
  final int? awayScore;
  final String status;

  const MatchModel({
    required this.id,
    required this.league,
    required this.home,
    required this.away,
    required this.time,
    required this.status,
    this.homeScore,
    this.awayScore,
  });

  factory MatchModel.fromMap(Map<String, dynamic> m) => MatchModel(
        id: '${m['id']}',
        league: '${m['league'] ?? ''}',
        home: '${m['home'] ?? ''}',
        away: '${m['away'] ?? ''}',
        time: '${m['time'] ?? ''}',
        status: '${m['status'] ?? 'scheduled'}',
        homeScore: m['home_score'] as int?,
        awayScore: m['away_score'] as int?,
      );
}
