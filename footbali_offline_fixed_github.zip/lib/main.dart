import 'package:flutter/material.dart';
import 'config.dart';
import 'football_api.dart';
import 'models.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const FootbaliApp());
}

class FootbaliApp extends StatelessWidget {
  const FootbaliApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'فوتبالی',
      theme: ThemeData(
        brightness: Brightness.dark,
        useMaterial3: true,
        scaffoldBackgroundColor: const Color(0xFF06131B),
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF39E6A6),
          brightness: Brightness.dark,
        ),
      ),
      home: const Shell(),
    );
  }
}

class Shell extends StatefulWidget {
  const Shell({super.key});
  @override State<Shell> createState() => _ShellState();
}

class _ShellState extends State<Shell> {
  int tab = 0;
  String? prediction;
  int points = 2500;
  final api = FootballApi();

  @override
  Widget build(BuildContext context) {
    final pages = [
      Home(api: api, onOpenMatch: () => setState(() => tab = 2)),
      const LeaguesPage(),
      const MatchPage(),
      PredictionPage(
        selected: prediction,
        onSelect: (v) => setState(() => prediction = v),
        onSubmit: () {
          if (prediction == null) return;
          if (points < 100) {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text('امتیاز کافی نداری.')),
            );
            return;
          }
          setState(() => points -= 100);
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('پیش‌بینی آزمایشی ثبت شد.')),
          );
        },
      ),
      Profile(points: points),
    ];

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        body: SafeArea(child: pages[tab]),
        bottomNavigationBar: NavigationBar(
          selectedIndex: tab,
          onDestinationSelected: (i) => setState(() => tab = i),
          destinations: const [
            NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'خانه'),
            NavigationDestination(icon: Icon(Icons.emoji_events_outlined), selectedIcon: Icon(Icons.emoji_events), label: 'لیگ‌ها'),
            NavigationDestination(icon: Icon(Icons.sports_soccer_outlined), selectedIcon: Icon(Icons.sports_soccer), label: 'مسابقات'),
            NavigationDestination(icon: Icon(Icons.track_changes_outlined), selectedIcon: Icon(Icons.track_changes), label: 'پیش‌بینی'),
            NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'پروفایل'),
          ],
        ),
      ),
    );
  }
}


class Home extends StatelessWidget {
  final FootballApi api;
  final VoidCallback onOpenMatch;
  const Home({super.key, required this.api, required this.onOpenMatch});

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('فوتبالی', style: TextStyle(fontWeight: FontWeight.w900))),
        body: FutureBuilder<List<MatchModel>>(
          future: api.todayMatches(),
          builder: (context, snap) {
            final matches = snap.data ?? const <MatchModel>[];
            return ListView(
              padding: const EdgeInsets.all(16),
              children: [
                const Text('امروز', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900)),
                const SizedBox(height: 18),
                Glass(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('امتیاز شما', style: TextStyle(color: Colors.white.withOpacity(.65))),
                      const SizedBox(height: 4),
                      const Text('۲٬۵۰۰', style: TextStyle(fontSize: 32, fontWeight: FontWeight.w900, color: Color(0xFF39E6A6))),
                    ],
                  ),
                ),
                const SizedBox(height: 18),
                const Text('بازی‌های مهم', style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
                const SizedBox(height: 10),
                ...matches.map((m) => Padding(
                      padding: const EdgeInsets.only(bottom: 12),
                      child: InkWell(
                        borderRadius: BorderRadius.circular(22),
                        onTap: onOpenMatch,
                        child: Glass(
                          child: Row(
                            children: [
                              Expanded(child: Text(m.home, textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.bold))),
                              Column(children: [
                                Text(m.time, style: const TextStyle(color: Color(0xFF39E6A6), fontWeight: FontWeight.bold)),
                                const SizedBox(height: 4),
                                Text(m.league, style: TextStyle(fontSize: 11, color: Colors.white.withOpacity(.55))),
                              ]),
                              Expanded(child: Text(m.away, textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.bold))),
                            ],
                          ),
                        ),
                      ),
                    )),
                if (AppConfig.hasFootballApi)
                  const Text('داده‌ها از Football API دریافت می‌شوند.', style: TextStyle(fontSize: 11, color: Colors.white54)),
              ],
            );
          },
        ),
      );
}


class LeaguesPage extends StatelessWidget {
  const LeaguesPage({super.key});

  static const leagues = [
    ('لیگ برتر انگلیس', '🇬🇧', 'Premier League', '20 تیم'),
    ('لالیگا', '🇪🇸', 'La Liga', '20 تیم'),
    ('سری‌آ', '🇮🇹', 'Serie A', '20 تیم'),
    ('بوندس‌لیگا', '🇩🇪', 'Bundesliga', '18 تیم'),
    ('لیگ قهرمانان اروپا', '🏆', 'UEFA Champions League', '36 تیم'),
  ];

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(
          title: const Text('لیگ‌ها', style: TextStyle(fontWeight: FontWeight.w900)),
        ),
        body: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            const Text(
              'لیگ‌های محبوب',
              style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900),
            ),
            const SizedBox(height: 8),
            Text(
              'مسابقات، جدول و اطلاعات لیگ موردنظر را دنبال کن.',
              style: TextStyle(color: Colors.white.withOpacity(.65)),
            ),
            const SizedBox(height: 20),
            ...leagues.map(
              (l) => Padding(
                padding: const EdgeInsets.only(bottom: 12),
                child: Glass(
                  child: InkWell(
                    borderRadius: BorderRadius.circular(22),
                    onTap: () {
                      Navigator.of(context).push(
                        MaterialPageRoute(
                          builder: (_) => LeagueDetailPage(
                            name: l.$1,
                            flag: l.$2,
                            englishName: l.$3,
                            teams: l.$4,
                          ),
                        ),
                      );
                    },
                    child: Row(
                      children: [
                        Container(
                          width: 54,
                          height: 54,
                          alignment: Alignment.center,
                          decoration: BoxDecoration(
                            color: Colors.white.withOpacity(.07),
                            borderRadius: BorderRadius.circular(18),
                          ),
                          child: Text(l.$2, style: const TextStyle(fontSize: 27)),
                        ),
                        const SizedBox(width: 14),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(l.$1, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
                              const SizedBox(height: 5),
                              Text('${l.$3} • ${l.$4}', style: TextStyle(fontSize: 12, color: Colors.white.withOpacity(.55))),
                            ],
                          ),
                        ),
                        const Icon(Icons.chevron_left, color: Colors.white54),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      );
}

class LeagueDetailPage extends StatelessWidget {
  final String name;
  final String flag;
  final String englishName;
  final String teams;

  const LeagueDetailPage({
    super.key,
    required this.name,
    required this.flag,
    required this.englishName,
    required this.teams,
  });

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: Text(name)),
        body: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Glass(
              child: Row(
                children: [
                  Text(flag, style: const TextStyle(fontSize: 42)),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(name, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
                        const SizedBox(height: 5),
                        Text('$englishName • $teams', style: const TextStyle(color: Colors.white60)),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 18),
            const Text('مسابقات', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),
            const Glass(
              child: Column(
                children: [
                  ListTile(
                    contentPadding: EdgeInsets.zero,
                    title: Text('آرسنال  —  لیورپول'),
                    subtitle: Text('امروز • ۱۸:۳۰'),
                    trailing: Text('پیش‌بینی', style: TextStyle(color: Color(0xFF39E6A6))),
                  ),
                  Divider(),
                  ListTile(
                    contentPadding: EdgeInsets.zero,
                    title: Text('منچسترسیتی  —  چلسی'),
                    subtitle: Text('فردا • ۲۱:۰۰'),
                    trailing: Text('پیش‌بینی', style: TextStyle(color: Color(0xFF39E6A6))),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 18),
            const Text('جدول لیگ', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),
            const Glass(
              child: Column(
                children: [
                  _TableRow(pos: '۱', team: 'آرسنال', pts: '۲۵'),
                  Divider(),
                  _TableRow(pos: '۲', team: 'لیورپول', pts: '۲۳'),
                  Divider(),
                  _TableRow(pos: '۳', team: 'منچسترسیتی', pts: '۲۱'),
                  Divider(),
                  _TableRow(pos: '۴', team: 'چلسی', pts: '۱۹'),
                ],
              ),
            ),
          ],
        ),
      );
}

class _TableRow extends StatelessWidget {
  final String pos;
  final String team;
  final String pts;
  const _TableRow({required this.pos, required this.team, required this.pts});

  @override
  Widget build(BuildContext context) => Row(
        children: [
          SizedBox(width: 28, child: Text(pos, style: const TextStyle(color: Colors.white54))),
          Expanded(child: Text(team, style: const TextStyle(fontWeight: FontWeight.bold))),
          Text('$pts امتیاز', style: const TextStyle(color: Color(0xFF39E6A6))),
        ],
      );
}

class MatchPage extends StatelessWidget {
  const MatchPage({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('جزئیات مسابقه')),
        body: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Glass(
              child: Column(
                children: [
                  const Text('لیگ قهرمانان اروپا', style: TextStyle(color: Color(0xFF39E6A6))),
                  const SizedBox(height: 18),
                  const Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      Text('رئال مادرید', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                      Text('—', style: TextStyle(fontSize: 30)),
                      Text('منچسترسیتی', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                    ],
                  ),
                  const SizedBox(height: 18),
                  const Text('امشب • ۲۲:۳۰', style: TextStyle(color: Colors.white70)),
                ],
              ),
            ),
            const SizedBox(height: 16),
            Glass(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: const [
              Text('آمار و رویدادها', style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
              SizedBox(height: 18),
              Text('ترکیب تیم‌ها بعد از دریافت داده زنده نمایش داده می‌شود.'),
              SizedBox(height: 12),
              Text('مالکیت توپ • شوت • کرنر • کارت • تعویض'),
            ])),
          ],
        ),
      );
}

class PredictionPage extends StatelessWidget {
  final String? selected;
  final ValueChanged<String> onSelect;
  final VoidCallback onSubmit;
  const PredictionPage({super.key, required this.selected, required this.onSelect, required this.onSubmit});

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('پیش‌بینی')),
        body: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Glass(
              child: Column(
                children: [
                  const Text('رئال مادرید  —  منچسترسیتی', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
                  const SizedBox(height: 8),
                  Text('۱۰۰ امتیاز مجازی برای هر پیش‌بینی', style: TextStyle(color: Colors.white.withOpacity(.65))),
                  const SizedBox(height: 22),
                  Row(
                    children: [
                      for (final item in [('1', 'برد رئال'), ('X', 'مساوی'), ('2', 'برد سیتی')])
                        Expanded(
                          child: Padding(
                            padding: const EdgeInsets.all(4),
                            child: ChoiceChip(
                              selected: selected == item.$1,
                              onSelected: (_) => onSelect(item.$1),
                              label: SizedBox(width: double.infinity, child: Text(item.$2, textAlign: TextAlign.center)),
                            ),
                          ),
                        ),
                    ],
                  ),
                  const SizedBox(height: 18),
                  SizedBox(
                    width: double.infinity,
                    child: FilledButton(
                      onPressed: selected == null ? null : onSubmit,
                      child: const Text('ثبت پیش‌بینی'),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      );
}

class Profile extends StatelessWidget {
  final int points;
  const Profile({super.key, required this.points});

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('پروفایل')),
        body: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Glass(
              child: const Column(children: [
                CircleAvatar(radius: 36, child: Icon(Icons.person, size: 38)),
                SizedBox(height: 12),
                Text('کاربر فوتبالی', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
              ]),
            ),
            const SizedBox(height: 14),
            Glass(child: ListTile(title: const Text('امتیاز مجازی'), trailing: Text('$points', style: const TextStyle(fontSize: 22, color: Color(0xFF39E6A6), fontWeight: FontWeight.bold)))),
            const SizedBox(height: 14),
            Glass(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: const [
              Text('جدول برترین‌ها', style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
              SizedBox(height: 16),
              Text('۱  کاربر فوتبالی                 ۲٬۵۰۰'),
              Divider(),
              Text('۲  Football Fan                 ۲٬۳۸۰'),
              Divider(),
              Text('۳  Goal Master                  ۲٬۲۱۰'),
            ])),
          ],
        ),
      );
}
