class AppConfig {
  static const supabaseUrl =
      String.fromEnvironment('SUPABASE_URL', defaultValue: '');
  static const supabaseAnonKey =
      String.fromEnvironment('SUPABASE_ANON_KEY', defaultValue: '');

  static const footballApiBaseUrl =
      String.fromEnvironment('FOOTBALL_API_BASE_URL', defaultValue: '');
  static const footballApiKey =
      String.fromEnvironment('FOOTBALL_API_KEY', defaultValue: '');

  static bool get hasSupabase =>
      supabaseUrl.isNotEmpty && supabaseAnonKey.isNotEmpty;

  static bool get hasFootballApi =>
      footballApiBaseUrl.isNotEmpty && footballApiKey.isNotEmpty;
}
